package Test;


import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class AutentificareTest {

    public WebDriver driver;

    @Test
    public void AutentificareTest() {

        System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver_win32\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.miniprix.ro/");
        driver.manage().window().maximize();


        new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@id='CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll']")));
        WebElement CookieButton = driver.findElement(By.id("CybotCookiebotDialogBodyLevelButtonLevelOptinAllowAll"));
        CookieButton.click();

        WebElement Autentificare = driver.findElement(By.xpath("//div[@class='gray flex items-center ']"));
        Autentificare.click();

        WebElement SwitchToMailandPassword = driver.findElement(By.xpath("//div[@class='vtex-login-2-x-options']"));
        SwitchToMailandPassword.click();

        List<WebElement> Cont = driver.findElements(By.xpath("//ul[@class='vtex-login-2-x-optionsList list pa0']/li"));
        Cont.get(3).click();

        WebElement EmailandPassword = driver.findElement(By.xpath("//div[@class='vtex-login-2-x-emailVerification vtex-login-2-x-emailAndPasswordForm w-100']"));
        EmailandPassword.click();

        WebElement Email = driver.findElement(By.xpath("//input[@type='text']"));
        Email.sendKeys("lucianaaus@yahoo.com");

        WebElement Password = driver.findElement(By.xpath("//input[@type='password']"));
        Password.sendKeys("Anastasia@21");
    }

}

